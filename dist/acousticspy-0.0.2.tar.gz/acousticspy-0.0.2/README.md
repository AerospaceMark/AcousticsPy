# acoustics

## To Run

Enter the python environment and type:

```
>> import sys; sys.path.append("path-to-acoustics-folder-on-computer")
>> import acoustics
```
